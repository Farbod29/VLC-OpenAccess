function App() {
  return <div className="text-teal-100"> Sosis</div>;
}

export default App;
