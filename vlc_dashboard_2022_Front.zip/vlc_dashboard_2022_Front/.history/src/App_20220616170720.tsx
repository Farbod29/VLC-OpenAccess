function App() {
  return <div className="App"> Sosis</div>;
}

export default App;
