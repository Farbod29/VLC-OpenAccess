import React from 'react'
const { useEffect, useState, useCallback } = require('react');
const {
  Grid,
  CircularProgress,
  TextField,
  MenuItem,
  AppBar,
  Toolbar,
  Typography,
} = require('@mui/material');
const { groupBy, orderBy } = require('lodash');
const { Chart } = require('react-google-charts');

const classificationType = ['Classification', 'Classification2'];
const Dashboard = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [experienceIds, setExperienceIds] = useState([]);

export default function App() {
  useEffect(() => {
    setLoading(true);
    fetchData();
  }, []);

  const fetchData = () => {
    fetch('http://localhost:3007/votes/list/allExperienceId', {
      method: 'GET',
      headers: {
        'content-type': 'application/json',
      },
    })
      .then((response) => response.json())
      .then((res) => {
        setLoading(false);
        // console.log('response of get image reaction', res);
        setExperienceIds(res);
      })
      .catch((err) => console.log(err));
  };
  return (
    <div>
    useEffect(() => {
    setLoading(true);
    fetchData();
  }, []);

  const fetchData = () => {
    fetch('http://localhost:3007/votes/list/allExperienceId', {
      method: 'GET',
      headers: {
        'content-type': 'application/json',
      },
    })
      .then((response) => response.json())
      .then((res) => {
        setLoading(false);
        // console.log('response of get image reaction', res);
        setExperienceIds(res);
      })
      .catch((err) => console.log(err));
  };
  </div>
  )
}
