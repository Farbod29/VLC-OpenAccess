import React, { useEffect, useState } from 'react';
import Select from 'react-select';

export default function App() {
  const [experienceIdsLoading, setExperienceIdsLoading] = useState(false);
  const [experienceIds, setExperienceIds] = useState([]);
  const options = experienceIds.map((item) => ({ value: item, label: item }));

  const [listOfDistinctImageUrlsLoading, setListOfDistinctImageUrlsLoading] =
    useState(false);
  const [imageUrls, setImageUrls] = useState([]);

  useEffect(() => {
    setExperienceIdsLoading(true);
    fetchDistinctExperienceIds();
  }, []);
  console.log(experienceIds);
  // console.log(imageUrls);

  const handleChangeExperienceId = (selectedExperienceId: any) => {
    console.log(selectedExperienceId);
  };

  const fetchDistinctExperienceIds = () => {
    fetch('http://localhost:3007/votes/list/allExperienceId', {
      method: 'GET',
      headers: {
        'content-type': 'application/json',
      },
    })
      .then((response) => response.json())
      .then((res) => {
        setExperienceIdsLoading(false);
        // console.log('response of get image reaction', res);
        setExperienceIds(res);
      })
      .catch((err) => {
        setExperienceIdsLoading(false);
        console.log(err);
      });
  };

  const fetchListOfDistinctImageUrls = () => {
    fetch(
      'http://localhost:3007/votes/list/experienceId?experienceId=RIAS17June',
      {
        method: 'GET',
        headers: {
          'content-type': 'application/json',
        },
      }
    )
      .then((response) => response.json())
      .then((res) => {
        setListOfDistinctImageUrlsLoading(false);
        // console.log('response of get image reaction', res);
        setImageUrls(res);
      })
      .catch((err) => {
        setListOfDistinctImageUrlsLoading(false);
        console.log(err);
      });
  };

  return (
    <div>
      App
      <Select onChange={handleChangeExperienceId} options={options} />
    </div>
  );
}
