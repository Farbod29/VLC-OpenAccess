import React, { useEffect, useState } from 'react';

export default function App() {
  const [loading, setLoading] = useState(false);
  const [experienceIds, setExperienceIds] = useState([]);

  useEffect(() => {
    setLoading(true);
    fetchDistinctExperienceIds();
  }, []);
  console.log(experienceIds);

  const fetchDistinctExperienceIds = () => {
    fetch('http://localhost:3007/votes/list/allExperienceId', {
      method: 'GET',
      headers: {
        'content-type': 'application/json',
      },
    })
      .then((response) => response.json())
      .then((res) => {
        setLoading(false);
        // console.log('response of get image reaction', res);
        setExperienceIds(res);
      })
      .catch((err) => {
        setLoading(false);
        console.log(err);
      });
  };

  const listOfDistinctImageUrls = () => {
    fetch('http://localhost:3007/votes/list/allExperienceId', {
      method: 'GET',
      headers: {
        'content-type': 'application/json',
      },
    })
      .then((response) => response.json())
      .then((res) => {
        setLoading(false);
        // console.log('response of get image reaction', res);
        setExperienceIds(res);
      })
      .catch((err) => console.log(err));
  };

  return <div>App</div>;
}
