function App() {
  return <div className="text-red-500"> Sosis</div>;
}

export default App;
